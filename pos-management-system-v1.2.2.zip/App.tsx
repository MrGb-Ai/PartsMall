
import React, { useState, useEffect, useRef } from 'react';
import TopNav from './components/TopNav';
import Login from './components/Login';
import DashboardHome from './components/DashboardHome';
import About from './components/About'; 
import ActivationScreen from './components/ActivationScreen';
import AllCustomersStatement from './components/AllCustomersStatement';
import AllSalesRepsStatement from './components/AllSalesRepsStatement';
import AllSuppliersStatement from './components/AllSuppliersStatement';
import AnalysisReport from './components/AnalysisReport';
import BackupSettings from './components/BackupSettings';
import CloudSettings from './components/CloudSettings';
import CompanySettings from './components/CompanySettings';
import CustomerManagement from './components/CustomerManagement';
import CustomerReceiptManagement from './components/CustomerReceiptManagement';
import CustomerStatement from './components/CustomerStatement';
import CustomerMovementComparison from './components/CustomerMovementComparison';
import DailyLedger from './components/DailyLedger';
import DefaultValuesComponent from './components/DefaultValues';
import DiscountManagement from './components/DiscountManagement';
import ExpenseCategoryManagement from './components/ExpenseCategoryManagement';
import ExpenseManagement from './components/ExpenseManagement';
import ExpenseReport from './components/ExpenseReport';
import FactoryReset from './components/FactoryReset';
import IncomeStatement from './components/IncomeStatement';
import WeeklyReport from './components/WeeklyReport';
import ItemManagement from './components/ItemManagement';
import ItemMovement from './components/ItemMovement';
import ItemSearch from './components/ItemSearch';
import ItemsInWarehouses from './components/ItemsInWarehouses';
import PurchaseInvoiceManagement from './components/PurchaseInvoiceManagement';
import PurchaseReport from './components/PurchaseReport';
import PurchaseReturnManagement from './components/PurchaseReturnManagement';
import SalesInvoiceManagement from './components/SalesInvoiceManagement';
import SalesReport from './components/SalesReport';
import SalesRepresentativeManagement from './components/SalesRepresentativeManagement';
import SalesRepStatement from './components/SalesRepStatement';
import SalesReturnManagement from './components/SalesReturnManagement';
import SettingsActivation from './components/SettingsActivation';
import SupplierManagement from './components/SupplierManagement';
import SupplierPaymentManagement from './components/SupplierPaymentManagement';
import SupplierStatement from './components/SupplierStatement';
import TreasuryManagement from './components/TreasuryManagement';
import TreasuryTransferManagement from './components/TreasuryTransferManagement';
import UnitManagement from './components/UnitManagement';
import UpdateManagement from './components/UpdateManagement';
import UserManagement from './components/UserManagement';
import UserPermissions from './components/UserPermissions';
import WarehouseInventory from './components/WarehouseInventory';
import WarehouseManagement from './components/WarehouseManagement';
import WarehouseTransferManagement from './components/WarehouseTransferManagement';
import ImportCostCalculator from './components/ImportCostCalculator';
import InitialSetup from './components/InitialSetup';
import AppUnlock from './components/AppUnlock';
import Salaries from './components/Salaries';
import Attendance from './components/Attendance';
import EmployeeManagement from './components/EmployeeManagement';
import DepartmentManagement from './components/DepartmentManagement';
import Chat from './components/Chat';
import { menuItems, ALL_PERMISSIONS } from './components/navigation';
import { initFirebase, writeToDb, subscribeToDb } from './services/firebase';
import { initDB, getTableData, saveTableData, saveSingleRow, resetDB } from './services/db';
import { initLicense, LicenseStatus } from './services/license';
import { checkGitHubUpdate } from './services/githubUpdate';
import { APP_VERSION } from './constants/version';
import { DownloadIcon, Modal, ActionFeedback, CloudIcon, DatabaseIcon, WarningIcon } from './components/Shared';
import type { 
    MgmtUser, CompanyData, Warehouse, Unit, Item, Treasury, ExpenseCategory, Expense, Customer, CustomerReceipt,
    SalesRepresentative, Supplier, SupplierPayment, SalesInvoice, SalesReturn, 
    PurchaseInvoice, PurchaseReturn, WarehouseTransfer, TreasuryTransfer, AppBackupData, NotificationType, DefaultValues, FirebaseConfig, StorableDiscountItem, DatabaseProfile,
    DocToView, PreselectedSalesRep, SavedImport, Employee, Department, ChatMessage
} from './types';

const useGlobalStorage = <T,>(key: string, initialValue: T): [T, React.Dispatch<React.SetStateAction<T>>] => {
  const [storedValue, setStoredValue] = useState<T>(() => {
    try {
      const item = window.localStorage.getItem(key);
      if (item) {
          const parsed = JSON.parse(item);
          return (parsed !== null && parsed !== undefined) ? parsed : initialValue;
      }
      return initialValue;
    } catch (error) {
      console.error(error);
      return initialValue;
    }
  });

  useEffect(() => {
    try {
      window.localStorage.setItem(key, JSON.stringify(storedValue));
    } catch (error) {
      console.error(error);
    }
  }, [key, storedValue]);

  return [storedValue, setStoredValue];
};

const App: React.FC = () => {
  const [firebaseConfig, setFirebaseConfig] = useGlobalStorage<FirebaseConfig | null>('pos_firebase_config', null);
  const [theme, setTheme] = useGlobalStorage<'light' | 'dark'>('pos_theme', 'light');
  const [activeDatabaseId, activeDatabaseIdSet] = useGlobalStorage<string>('pos_active_database_id', '');
  const [isSetupComplete, setIsSetupComplete] = useGlobalStorage<boolean>('pos_setup_complete', false);
  const [isCloudConnected, setIsCloudConnected] = useState(false);
  const [isDBReady, setIsDBReady] = useState(false);
  const [licenseStatus, setLicenseStatus] = useState<LicenseStatus | null>(null);
  const [checkingLicense, setCheckingLicense] = useState(true);
  const [showManualActivation, setShowManualActivation] = useState(false);
  const [updateAvailable, setUpdateAvailable] = useState(false);
  const [isLogoutModalOpen, setIsLogoutModalOpen] = useState(false);
  const [notification, setNotification] = useState<NotificationType | null>(null);
  const [latestVersion, setLatestVersion] = useState<string>('');
  const [downloadUrl, setDownloadUrl] = useState<string>('');
  const [releaseNotes, setReleaseNotes] = useState<string>('');
  
  const useSyncedState = <T,>(tableName: string, initialValue: T, customDbId?: string): [T, React.Dispatch<React.SetStateAction<T>>] => {
    const [storedValue, setStoredValue] = useState<T>(initialValue);
    const isRemoteUpdate = useRef(false);
    const hasSyncedWithCloud = useRef(false);
    const localValueRef = useRef(storedValue);

    useEffect(() => { localValueRef.current = storedValue; }, [storedValue]);

    const effectiveDbId = customDbId !== undefined ? customDbId : activeDatabaseId;

    useEffect(() => {
        if (!isDBReady) return;
        const load = async () => {
            try {
                const data = await getTableData(tableName);
                if (data !== null && data !== undefined) {
                    setStoredValue(data as T);
                }
            } catch (err) { console.error(`Failed to load ${tableName}`, err); }
        };
        load();
    }, [isDBReady, tableName]);

    useEffect(() => {
        hasSyncedWithCloud.current = false;
        if (!isCloudConnected || !isDBReady) return;
        const unsubscribe = subscribeToDb(effectiveDbId, tableName, (data) => {
            const isFirstSync = !hasSyncedWithCloud.current;
            hasSyncedWithCloud.current = true; 
            if (data !== null && data !== undefined) {
                isRemoteUpdate.current = true;
                setStoredValue(data);
                if (Array.isArray(data)) saveTableData(tableName, data);
                else saveSingleRow(tableName, data);
                setTimeout(() => { isRemoteUpdate.current = false; }, 500);
            } else if (isFirstSync) {
                 const localData = localValueRef.current;
                 const hasLocalData = Array.isArray(localData) ? localData.length > 0 : (localData && Object.keys(localData).length > 0 && JSON.stringify(localData) !== JSON.stringify(initialValue));
                if (hasLocalData) writeToDb(effectiveDbId, tableName, localData);
            }
        });
        return () => unsubscribe();
    }, [isCloudConnected, isDBReady, effectiveDbId, tableName]);

    useEffect(() => {
        if (!isDBReady) return;
        const isRemote = isRemoteUpdate.current;
        let savePromise = Array.isArray(storedValue) ? saveTableData(tableName, storedValue) : saveSingleRow(tableName, storedValue);
        savePromise.then(() => {
            if (isCloudConnected && !isRemote && hasSyncedWithCloud.current) {
                writeToDb(effectiveDbId, tableName, storedValue);
            }
        });
    }, [storedValue, tableName, isDBReady, isCloudConnected, effectiveDbId]);

    return [storedValue, setStoredValue];
  };

  const defaultCompanyData: CompanyData = { name: 'اسم الشركة', cr: '', tr: '', phone1: '', phone2: '', address: '' };
  const defaultDefaultValues: DefaultValues = { defaultWarehouseId: 1, defaultUnitId: 1, defaultSalesRepId: 0, defaultTreasuryId: 1, defaultPaymentMethodInvoices: 'credit', defaultPaymentMethodReceipts: 'cash', invoiceFooter: '', whatsappFooter: '', enableBackupAlert: true, backgroundImage: '' };

  const [databases, setDatabases] = useSyncedState<DatabaseProfile[]>('databases', [{ id: '', name: 'البيانات الرئيسية (السحابة)' }], 'SYSTEM_METADATA');
  const [users, setUsers] = useSyncedState<MgmtUser[]>('users', []);
  const [companyData, setCompanyData] = useSyncedState<CompanyData>('companyData', defaultCompanyData);
  const [warehouses, setWarehouses] = useSyncedState<Warehouse[]>('warehouses', [{ id: 1, code: '1', name: 'الفرع الرئيسي', keeper: '', phone: '', address: '', notes: '' }]);
  const [units, setUnits] = useSyncedState<Unit[]>('units', [{ id: 1, name: 'عدد', description: '' }]);
  const [items, setItems] = useSyncedState<Item[]>('items', []);
  const [treasuries, setTreasuries] = useSyncedState<Treasury[]>('treasuries', [{ id: 1, name: 'الخزينة الرئيسية', keeper: '', openingBalance: 0 }]);
  const [expenseCategories, setExpenseCategories] = useSyncedState<ExpenseCategory[]>('expenseCategories', []);
  const [expenses, setExpenses] = useSyncedState<Expense[]>('expenses', []);
  const [customers, setCustomers] = useSyncedState<Customer[]>('customers', [{ id: 3, name: 'العميل النقدي', phone: '', address: '', openingBalance: 0 }]);
  const [customerReceipts, setCustomerReceipts] = useSyncedState<CustomerReceipt[]>('customerReceipts', []);
  const [salesRepresentatives, setSalesRepresentatives] = useSyncedState<SalesRepresentative[]>('salesRepresentatives', []);
  const [suppliers, setSuppliers] = useSyncedState<Supplier[]>('suppliers', []);
  const [supplierPayments, setSupplierPayments] = useSyncedState<SupplierPayment[]>('supplierPayments', []);
  const [salesInvoices, setSalesInvoices] = useSyncedState<SalesInvoice[]>('salesInvoices', []);
  const [heldInvoices, setHeldInvoices] = useSyncedState<SalesInvoice[]>('heldInvoices', []); 
  const [heldPurchaseInvoices, setHeldPurchaseInvoices] = useSyncedState<PurchaseInvoice[]>('heldPurchaseInvoices', []); 
  const [salesReturns, setSalesReturns] = useSyncedState<SalesReturn[]>('salesReturns', []);
  const [purchaseInvoices, setPurchaseInvoices] = useSyncedState<PurchaseInvoice[]>('purchaseInvoices', []);
  const [purchaseReturns, setPurchaseReturns] = useSyncedState<PurchaseReturn[]>('purchaseReturns', []);
  const [warehouseTransfers, setWarehouseTransfers] = useSyncedState<WarehouseTransfer[]>('warehouseTransfers', []);
  const [treasuryTransfers, setTreasuryTransfers] = useSyncedState<TreasuryTransfer[]>('treasuryTransfers', []);
  const [defaultValues, setDefaultValues] = useSyncedState<DefaultValues>('defaultValues', defaultDefaultValues);
  const [activeDiscounts, setActiveDiscounts] = useSyncedState<Record<number, number>>('activeDiscounts', {});
  const [selectedDiscountItems, setSelectedDiscountItems] = useSyncedState<StorableDiscountItem[]>('selectedDiscountItems', []);
  const [importCalculatorHistory, setImportCalculatorHistory] = useSyncedState<SavedImport[]>('importCalculatorHistory', []);
  const [employees, setEmployees] = useSyncedState<Employee[]>('employees', []);
  const [departments, setDepartments] = useSyncedState<Department[]>('departments', []);
  const [chatMessages, setChatMessages] = useSyncedState<ChatMessage[]>('chatMessages', []);

  useEffect(() => {
    if (defaultValues.githubRepo) {
      checkGitHubUpdate(defaultValues.githubRepo, APP_VERSION).then(info => {
        setLatestVersion(info.latestVersion);
        setDownloadUrl(info.downloadUrl);
        setReleaseNotes(info.releaseNotes);
        if (info.hasUpdate) {
          setUpdateAvailable(true);
        } else {
          setUpdateAvailable(false);
        }
      });
    }
  }, [defaultValues.githubRepo]);

  const [salesInvoiceDraft, setSalesInvoiceDraft] = useState<SalesInvoice | null>(null);
  const [salesInvoiceIsEditing, setSalesInvoiceIsEditing] = useState(false);
  const [purchaseInvoiceDraft, setPurchaseInvoiceDraft] = useState<PurchaseInvoice | null>(null);
  const [purchaseInvoiceIsEditing, setPurchaseInvoiceIsEditing] = useState(false);
  const [salesReturnDraft, setSalesReturnDraft] = useState<SalesReturn | null>(null);
  const [salesReturnIsEditing, setSalesReturnIsEditing] = useState(false);
  const [purchaseReturnDraft, setPurchaseReturnDraft] = useState<PurchaseReturn | null>(null);
  const [purchaseReturnIsEditing, setPurchaseReturnIsEditing] = useState(false);
  const [expenseDraft, setExpenseDraft] = useState<any>(null);
  const [expenseIsEditing, setExpenseIsEditing] = useState(false);
  const [customerReceiptDraft, setCustomerReceiptDraft] = useState<any>(null);
  const [customerReceiptIsEditing, setCustomerReceiptIsEditing] = useState(false);
  const [supplierPaymentDraft, setSupplierPaymentDraft] = useState<any>(null);
  const [supplierPaymentIsEditing, setSupplierPaymentIsEditing] = useState(false);
  const [warehouseTransferDraft, setWarehouseTransferDraft] = useState<any>(null);
  const [warehouseTransferIsEditing, setWarehouseTransferIsEditing] = useState(false);
  const [treasuryTransferDraft, setTreasuryTransferDraft] = useState<any>(null);
  const [treasuryTransferIsEditing, setTreasuryTransferIsEditing] = useState(false);

  const [currentView, setCurrentView] = useState('dashboard');
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [currentUser, setCurrentUser] = useState<MgmtUser | null>(null);
  const [docToView, setDocToView] = useState<DocToView>(null);
  const [preselectedCustomer, setPreselectedCustomer] = useState<number | null>(null);
  const [preselectedSupplier, setPreselectedSupplier] = useState<number | null>(null);
  const [preselectedSalesRep, setPreselectedSalesRep] = useState<PreselectedSalesRep>(null);

  useEffect(() => {
    if (theme === 'dark') document.documentElement.classList.add('dark');
    else document.documentElement.classList.remove('dark');
  }, [theme]);

  useEffect(() => {
      let isCancelled = false;
      const setup = async () => {
          try {
              const db = await initDB();
              if (isCancelled) return;
              setIsDBReady(true);
              const status = await initLicense();
              if (isCancelled) return;
              setLicenseStatus(status);
          } catch (e) {
              console.error("Initialization failed:", e);
              if (!isCancelled) setIsDBReady(true); 
          } finally {
              if (!isCancelled) setCheckingLicense(false);
          }
      };
      setup();
      return () => { isCancelled = true; };
  }, []);
    
  useEffect(() => {
    if (firebaseConfig) {
        initFirebase(firebaseConfig, (isConnected) => { setIsCloudConnected(isConnected); });
    } else { setIsCloudConnected(false); }
  }, [firebaseConfig]);

  useEffect(() => {
    const handleLogTransaction = (e: CustomEvent) => {
      const messageText = e.detail;
      if (!currentUser) return;
      const message: ChatMessage = {
          id: Date.now().toString(),
          channelId: 'transactions',
          senderId: currentUser.id,
          senderName: currentUser.fullName,
          text: messageText,
          timestamp: Date.now(),
      };
      setChatMessages(prev => {
          const safePrev = Array.isArray(prev) ? prev : [];
          return [...safePrev, message];
      });
    };
    window.addEventListener('logTransaction', handleLogTransaction as EventListener);
    return () => window.removeEventListener('logTransaction', handleLogTransaction as EventListener);
  }, [currentUser, setChatMessages]);

  const showNotification = (type: NotificationType) => {
    setNotification(type);
    setTimeout(() => setNotification(null), 3000);
  };

  const handleLogin = (user: MgmtUser) => {
    setCurrentUser(user);
    setIsLoggedIn(true);
    if (!isSetupComplete) {
      setCurrentView('initialSetup');
    } else {
      setCurrentView('dashboard');
    }
  };
  
  const handleInitialSetupChoice = (choice: 'cloud' | 'local') => {
    setIsSetupComplete(true);
    if (choice === 'cloud') setCurrentView('cloudSettings');
    else setCurrentView('dashboard');
  };

  const performLogout = () => {
    setIsLoggedIn(false);
    setCurrentUser(null);
    setCurrentView('dashboard');
    setIsLogoutModalOpen(false);
  };

  const handleLogout = () => {
    setIsLogoutModalOpen(true);
  };

  const handleRestoreAppData = async (data: AppBackupData) => {
    try {
        const keys = Object.keys(data);
        for (const key of keys) {
            const value = (data as any)[key];
            if (value !== undefined && value !== null) {
                if (Array.isArray(value)) {
                    await saveTableData(key, value);
                } else {
                    await saveSingleRow(key, value);
                }
            }
        }
        showNotification('save');
        localStorage.setItem('pos_setup_complete', JSON.stringify(true));
        alert("تمت استعادة البيانات بنجاح. سيتم إعادة تشغيل البرنامج لتطبيق التغييرات.");
        window.location.reload();
    } catch (error) {
        console.error("Restore failed:", error);
        alert("فشل عملية استعادة البيانات.");
    }
  };

  const renderCurrentView = () => {
    switch (currentView) {
      case 'initialSetup': return <InitialSetup onChoice={handleInitialSetupChoice} />;
      case 'dashboard': return <DashboardHome setCurrentView={setCurrentView} salesInvoices={salesInvoices} salesReturns={salesReturns} purchaseInvoices={purchaseInvoices} purchaseReturns={purchaseReturns} customers={customers} customerReceipts={customerReceipts} items={items} expenses={expenses} expenseCategories={expenseCategories} suppliers={suppliers} supplierPayments={supplierPayments} treasuries={treasuries} treasuryTransfers={treasuryTransfers} warehouses={warehouses} defaultValues={defaultValues} />;
      case 'userManagement': return <UserManagement users={users} setUsers={setUsers} showNotification={showNotification} currentUser={currentUser!} employees={employees} />;
      case 'userPermissions': return <UserPermissions users={users} setUsers={setUsers} showNotification={showNotification} />;
      case 'companySettings': return <CompanySettings companyData={companyData} setCompanyData={setCompanyData} showNotification={showNotification} />;
      case 'departmentManagement': return <DepartmentManagement />;
      case 'cloudSettings': return <CloudSettings firebaseConfig={firebaseConfig} setFirebaseConfig={setFirebaseConfig} showNotification={showNotification} />;
      case 'defaultValues': return <DefaultValuesComponent defaultValues={defaultValues} setDefaultValues={setDefaultValues} warehouses={warehouses} units={units} salesRepresentatives={salesRepresentatives} treasuries={treasuries} showNotification={showNotification} />;
      case 'backupSettings': return <BackupSettings appData={{users, companyData, warehouses, units, items, treasuries, expenseCategories, expenses, customers, customerReceipts, salesRepresentatives, suppliers, supplierPayments, salesInvoices, salesReturns, purchaseInvoices, purchaseReturns, warehouseTransfers, treasuryTransfers, defaultValues, activeDiscounts, selectedDiscountItems, importCalculatorHistory}} onRestore={handleRestoreAppData} showNotification={showNotification} databases={databases} setDatabases={setDatabases} activeDatabaseId={activeDatabaseId} setActiveDatabaseId={activeDatabaseIdSet} allDataKeys={[]} />;
      case 'factoryReset': return <FactoryReset onConfirmReset={() => resetDB()} />;
      case 'settingsActivation': return <SettingsActivation licenseStatus={licenseStatus} />;
      case 'updateManagement': return <UpdateManagement licenseStatus={licenseStatus} latestVersion={latestVersion} downloadUrl={downloadUrl} releaseNotes={releaseNotes} />;
      case 'warehouseManagement': return <WarehouseManagement warehouses={warehouses} setWarehouses={setWarehouses} items={items} setItems={setItems} showNotification={showNotification} currentUser={currentUser!} employees={employees} />;
      case 'unitManagement': return <UnitManagement units={units} setUnits={setUnits} items={items} setItems={setItems} showNotification={showNotification} currentUser={currentUser!} />;
      case 'itemManagement': return <ItemManagement items={items} setItems={setItems} units={units} warehouses={warehouses} showNotification={showNotification} currentUser={currentUser!} defaultValues={defaultValues} salesInvoices={salesInvoices} salesReturns={salesReturns} purchaseInvoices={purchaseInvoices} purchaseReturns={purchaseReturns} warehouseTransfers={warehouseTransfers} companyData={companyData} />;
      case 'treasuryManagement': return <TreasuryManagement treasuries={treasuries} setTreasuries={setTreasuries} showNotification={showNotification} salesInvoices={salesInvoices} purchaseInvoices={purchaseInvoices} salesReturns={salesReturns} purchaseReturns={purchaseReturns} customerReceipts={customerReceipts} supplierPayments={supplierPayments} expenses={expenses} treasuryTransfers={treasuryTransfers} currentUser={currentUser!} defaultValues={defaultValues} employees={employees} />;
      case 'expenseCategoryManagement': return <ExpenseCategoryManagement expenseCategories={expenseCategories} setExpenseCategories={setExpenseCategories} showNotification={showNotification} currentUser={currentUser!} />;
      case 'expenseManagement': return <ExpenseManagement expenses={expenses} setExpenses={setExpenses} expenseCategories={expenseCategories} treasuries={treasuries} showNotification={showNotification} currentUser={currentUser!} defaultValues={defaultValues} customerReceipts={customerReceipts} supplierPayments={supplierPayments} treasuryTransfers={treasuryTransfers} salesInvoices={salesInvoices} purchaseInvoices={purchaseInvoices} salesReturns={salesReturns} purchaseReturns={purchaseReturns} draft={expenseDraft} setDraft={setExpenseDraft} isEditing={expenseIsEditing} setIsEditing={setExpenseIsEditing} />;
      case 'customerManagement': return <CustomerManagement customers={customers} setCustomers={setCustomers} showNotification={showNotification} currentUser={currentUser!} salesInvoices={salesInvoices} salesReturns={salesReturns} customerReceipts={customerReceipts} />;
      case 'customerReceipt': return <CustomerReceiptManagement customerReceipts={customerReceipts} setCustomerReceipts={setCustomerReceipts} customers={customers} treasuries={treasuries} showNotification={showNotification} docToView={docToView} onClearDocToView={() => setDocToView(null)} currentUser={currentUser!} salesInvoices={salesInvoices} salesReturns={salesReturns} purchaseInvoices={purchaseInvoices} purchaseReturns={purchaseReturns} defaultValues={defaultValues} companyData={companyData} supplierPayments={supplierPayments} expenses={expenses} treasuryTransfers={treasuryTransfers} draft={customerReceiptDraft} setDraft={setCustomerReceiptDraft} isEditing={customerReceiptIsEditing} setIsEditing={setCustomerReceiptIsEditing} />;
      case 'salesRepresentativeManagement': return <SalesRepresentativeManagement salesRepresentatives={salesRepresentatives} setSalesRepresentatives={setSalesRepresentatives} showNotification={showNotification} currentUser={currentUser!} salesInvoices={salesInvoices} salesReturns={salesReturns} employees={employees} />;
      case 'supplierManagement': return <SupplierManagement suppliers={suppliers} setSuppliers={setSuppliers} showNotification={showNotification} currentUser={currentUser!} purchaseInvoices={purchaseInvoices} purchaseReturns={purchaseReturns} supplierPayments={supplierPayments} />;
      case 'supplierPayment': return <SupplierPaymentManagement supplierPayments={supplierPayments} setSupplierPayments={setSupplierPayments} suppliers={suppliers} treasuries={treasuries} showNotification={showNotification} docToView={docToView} onClearDocToView={() => setDocToView(null)} currentUser={currentUser!} purchaseInvoices={purchaseInvoices} purchaseReturns={purchaseReturns} salesInvoices={salesInvoices} salesReturns={salesReturns} defaultValues={defaultValues} companyData={companyData} customerReceipts={customerReceipts} expenses={expenses} treasuryTransfers={treasuryTransfers} draft={supplierPaymentDraft} setDraft={setSupplierPaymentDraft} isEditing={supplierPaymentIsEditing} setIsEditing={setSupplierPaymentIsEditing} />;
      case 'salesInvoice': return <SalesInvoiceManagement salesInvoices={salesInvoices} setSalesInvoices={setSalesInvoices} heldInvoices={heldInvoices} setHeldInvoices={setHeldInvoices} salesReturns={salesReturns} customerReceipts={customerReceipts} items={items} setItems={setItems} customers={customers} setCustomers={setCustomers} salesRepresentatives={salesRepresentatives} warehouses={warehouses} units={units} companyData={companyData} showNotification={showNotification} docToView={docToView} onClearDocToView={() => setDocToView(null)} currentUser={currentUser!} defaultValues={defaultValues} activeDiscounts={activeDiscounts} draft={salesInvoiceDraft} setDraft={setSalesInvoiceDraft} isEditing={salesInvoiceIsEditing} setIsEditing={setSalesInvoiceIsEditing} purchaseInvoices={purchaseInvoices} purchaseReturns={purchaseReturns} />;
      case 'salesReturn': return <SalesReturnManagement salesReturns={salesReturns} setSalesReturns={setSalesReturns} salesInvoices={salesInvoices} customerReceipts={customerReceipts} items={items} setItems={setItems} customers={customers} salesRepresentatives={salesRepresentatives} warehouses={warehouses} units={units} companyData={companyData} showNotification={showNotification} docToView={docToView} onClearDocToView={() => setDocToView(null)} currentUser={currentUser!} defaultValues={defaultValues} draft={salesReturnDraft} setDraft={setSalesReturnDraft} isEditing={salesReturnIsEditing} setIsEditing={setSalesReturnIsEditing} purchaseInvoices={purchaseInvoices} purchaseReturns={purchaseReturns} expenses={expenses} treasuryTransfers={treasuryTransfers} treasuries={treasuries} supplierPayments={supplierPayments} />;
      case 'purchaseInvoice': return <PurchaseInvoiceManagement purchaseInvoices={purchaseInvoices} setPurchaseInvoices={setPurchaseInvoices} heldPurchaseInvoices={heldPurchaseInvoices} setHeldPurchaseInvoices={setHeldPurchaseInvoices} purchaseReturns={purchaseReturns} supplierPayments={supplierPayments} items={items} setItems={setItems} suppliers={suppliers} setSuppliers={setSuppliers} warehouses={warehouses} units={units} companyData={companyData} showNotification={showNotification} docToView={docToView} onClearDocToView={() => setDocToView(null)} currentUser={currentUser!} defaultValues={defaultValues} draft={purchaseInvoiceDraft} setDraft={setPurchaseInvoiceDraft} isEditing={purchaseInvoiceIsEditing} setIsEditing={setPurchaseInvoiceIsEditing} salesInvoices={salesInvoices} salesReturns={salesReturns} expenses={expenses} customerReceipts={customerReceipts} treasuryTransfers={treasuryTransfers} treasuries={treasuries} />;
      case 'purchaseReturn': return <PurchaseReturnManagement purchaseReturns={purchaseReturns} setPurchaseReturns={setPurchaseReturns} purchaseInvoices={purchaseInvoices} supplierPayments={supplierPayments} items={items} setItems={setItems} suppliers={suppliers} warehouses={warehouses} units={units} companyData={companyData} showNotification={showNotification} docToView={docToView} onClearDocToView={() => setDocToView(null)} currentUser={currentUser!} defaultValues={defaultValues} draft={purchaseReturnDraft} setDraft={setPurchaseReturnDraft} isEditing={purchaseReturnIsEditing} setIsEditing={setPurchaseReturnIsEditing} salesInvoices={salesInvoices} salesReturns={salesReturns} customerReceipts={customerReceipts} expenses={expenses} treasuryTransfers={treasuryTransfers} treasuries={treasuries} />;
      case 'warehouseTransfer': return <WarehouseTransferManagement warehouseTransfers={warehouseTransfers} setWarehouseTransfers={setWarehouseTransfers} items={items} setItems={setItems} warehouses={warehouses} units={units} showNotification={showNotification} currentUser={currentUser!} draft={warehouseTransferDraft} setDraft={setWarehouseTransferDraft} isEditing={warehouseTransferIsEditing} setIsEditing={setWarehouseTransferIsEditing} salesInvoices={salesInvoices} salesReturns={salesReturns} purchaseInvoices={purchaseInvoices} purchaseReturns={purchaseReturns} />;
      case 'treasuryTransfer': return <TreasuryTransferManagement treasuryTransfers={treasuryTransfers} setTreasuryTransfers={setTreasuryTransfers} treasuries={treasuries} showNotification={showNotification} currentUser={currentUser!} customerReceipts={customerReceipts} supplierPayments={supplierPayments} expenses={expenses} salesInvoices={salesInvoices} purchaseInvoices={purchaseInvoices} salesReturns={salesReturns} purchaseReturns={purchaseReturns} defaultValues={defaultValues} draft={treasuryTransferDraft} setDraft={setTreasuryTransferDraft} isEditing={treasuryTransferIsEditing} setIsEditing={setTreasuryTransferIsEditing} />;
      case 'importCostCalculator': return <ImportCostCalculator companyData={companyData} items={items} setItems={setItems} units={units} warehouses={warehouses} defaultValues={defaultValues} showNotification={showNotification} purchaseInvoices={purchaseInvoices} setPurchaseInvoices={setPurchaseInvoices} suppliers={suppliers} setSuppliers={setSuppliers} currentUser={currentUser!} savedMessages={importCalculatorHistory} setSavedMessages={setImportCalculatorHistory} salesInvoices={salesInvoices} salesReturns={salesReturns} purchaseReturns={purchaseReturns} />;
      case 'warehouseInventory': return <WarehouseInventory items={items} setItems={setItems} warehouses={warehouses} companyData={companyData} users={users} showNotification={showNotification} salesInvoices={salesInvoices} salesReturns={salesReturns} purchaseInvoices={purchaseInvoices} purchaseReturns={purchaseReturns} />;
      case 'itemsInWarehouses': return <ItemsInWarehouses items={items} warehouses={warehouses} companyData={companyData} salesInvoices={salesInvoices} salesReturns={salesReturns} purchaseInvoices={purchaseInvoices} purchaseReturns={purchaseReturns} />;
      case 'salesReport': return <SalesReport salesInvoices={salesInvoices} salesReturns={salesReturns} items={items} customers={customers} salesRepresentatives={salesRepresentatives} warehouses={warehouses} companyData={companyData} onViewDoc={(view, id) => { setDocToView({ view, docId: id }); setCurrentView(view); }} />;
      case 'purchaseReport': return <PurchaseReport purchaseInvoices={purchaseInvoices} purchaseReturns={purchaseReturns} items={items} suppliers={suppliers} warehouses={warehouses} companyData={companyData} onViewDoc={(view, id) => { setDocToView({ view, docId: id }); setCurrentView(view); }} />;
      case 'analysisReport': return <AnalysisReport salesInvoices={salesInvoices} salesReturns={salesReturns} items={items} customers={customers} />;
      case 'customerStatement': return <CustomerStatement customers={customers} salesInvoices={salesInvoices} salesReturns={salesReturns} customerReceipts={customerReceipts} items={items} onViewDoc={(view, id) => { setDocToView({ view, docId: id }); setCurrentView(view); }} companyData={companyData} preselectedCustomer={preselectedCustomer} onClearPreselectedCustomer={() => setPreselectedCustomer(null)} defaultValues={defaultValues} />;
      case 'allCustomersStatement': return <AllCustomersStatement customers={customers} salesInvoices={salesInvoices} salesReturns={salesReturns} customerReceipts={customerReceipts} companyData={companyData} onViewCustomerStatement={(id) => { setPreselectedCustomer(id); setCurrentView('customerStatement'); }} defaultValues={defaultValues} />;
      case 'customerMovementComparison': return <CustomerMovementComparison customers={customers} salesInvoices={salesInvoices} salesReturns={salesReturns} customerReceipts={customerReceipts} companyData={companyData} defaultValues={defaultValues} />;
      case 'supplierStatement': return <SupplierStatement suppliers={suppliers} purchaseInvoices={purchaseInvoices} purchaseReturns={purchaseReturns} supplierPayments={supplierPayments} items={items} onViewDoc={(view, id) => { setDocToView({ view, docId: id }); setCurrentView(view); }} companyData={companyData} preselectedSupplier={preselectedSupplier} onClearPreselectedSupplier={() => setPreselectedSupplier(null)} defaultValues={defaultValues} />;
      case 'allSuppliersStatement': return <AllSuppliersStatement suppliers={suppliers} purchaseInvoices={purchaseInvoices} purchaseReturns={purchaseReturns} supplierPayments={supplierPayments} companyData={companyData} onViewSupplierStatement={(id) => { setPreselectedSupplier(id); setCurrentView('supplierStatement'); }} defaultValues={defaultValues} />;
      case 'salesRepStatement': return <SalesRepStatement salesRepresentatives={salesRepresentatives} salesInvoices={salesInvoices} salesReturns={salesReturns} customers={customers} companyData={companyData} onViewDoc={(view, id) => { setDocToView({ view, docId: id }); setCurrentView(view); }} preselectedSalesRep={preselectedSalesRep} onClearPreselectedSalesRep={() => setPreselectedSalesRep(null)} defaultValues={defaultValues} />;
      case 'allSalesRepsStatement': return <AllSalesRepsStatement salesRepresentatives={salesRepresentatives} salesInvoices={salesInvoices} salesReturns={salesReturns} onViewSalesRepStatement={(repId, startDate, endDate) => { setPreselectedSalesRep({ repId, startDate, endDate }); setCurrentView('salesRepStatement'); }} />;
      case 'itemMovement': return <ItemMovement items={items} warehouses={warehouses} salesInvoices={salesInvoices} salesReturns={salesReturns} purchaseInvoices={purchaseInvoices} purchaseReturns={purchaseReturns} warehouseTransfers={warehouseTransfers} companyData={companyData} onViewDoc={(view, id) => { setDocToView({ view, docId: id }); setCurrentView(view); }} defaultValues={defaultValues} customers={customers} suppliers={suppliers} />;
      case 'dailyLedger': return <DailyLedger salesInvoices={salesInvoices} salesReturns={salesReturns} expenses={expenses} purchaseInvoices={purchaseInvoices} purchaseReturns={purchaseReturns} customerReceipts={customerReceipts} supplierPayments={supplierPayments} treasuryTransfers={treasuryTransfers} expenseCategories={expenseCategories} treasuries={treasuries} defaultValues={defaultValues} />;
      case 'expenseReport': return <ExpenseReport expenses={expenses} expenseCategories={expenseCategories} treasuries={treasuries} companyData={companyData} defaultValues={defaultValues} />;
      case 'incomeStatement': return <IncomeStatement salesInvoices={salesInvoices} salesReturns={salesReturns} expenses={expenses} items={items} companyData={companyData} defaultValues={defaultValues} expenseCategories={expenseCategories} />;
      case 'weeklyReport': return <WeeklyReport salesInvoices={salesInvoices} salesReturns={salesReturns} purchaseInvoices={purchaseInvoices} purchaseReturns={purchaseReturns} customerReceipts={customerReceipts} items={items} companyData={companyData} defaultValues={defaultValues} />;
      case 'itemSearch': return <ItemSearch items={items} warehouses={warehouses} />;
      case 'discountManagement': return <DiscountManagement items={items} companyData={companyData} activeDiscounts={activeDiscounts} setActiveDiscounts={setActiveDiscounts} showNotification={showNotification} selectedDiscountItems={selectedDiscountItems} setSelectedDiscountItems={setSelectedDiscountItems} />;
      case 'salaries': return <Salaries />;
      case 'attendance': return <Attendance />;
      case 'employeeManagement': return <EmployeeManagement employees={employees} setEmployees={setEmployees} currentUser={currentUser!} />;
      case 'appUnlock': return <AppUnlock users={users} setUsers={setUsers} showNotification={showNotification} />;
      case 'about': return <About updateAvailable={updateAvailable} onNavigate={setCurrentView} activeDatabaseName={databases?.find(d => d.id === activeDatabaseId)?.name || 'البيانات الرئيسية (السحابة)'} isDBReady={isDBReady} isCloudConnected={isCloudConnected} />;
      
      default: return <div>View not found</div>;
    }
  };

  const currentViewLabel = menuItems.reduce((acc, item) => {
      if (item.id === currentView) return item.label;
      if (item.subItems) {
          const sub = item.subItems.find(s => s.id === currentView);
          if (sub) return sub.label;
      }
      return acc;
  }, 'لوحة التحكم');

  if (!isDBReady || (checkingLicense && !licenseStatus)) {
      return (
          <div className="flex h-screen w-full items-center justify-center bg-gray-100 dark:bg-gray-900 flex-col">
              <div className="animate-spin rounded-full h-16 w-16 border-t-4 border-blue-500 border-opacity-50"></div>
              <p className="mt-4 text-gray-600 dark:text-gray-300 text-lg font-semibold">
                  {checkingLicense ? 'جاري التحقق من الترخيص...' : 'جاري تحميل قاعدة البيانات...'}
              </p>
          </div>
      )
  }

  if ((licenseStatus && licenseStatus.isExpired) || showManualActivation) {
      return (
          <ActivationScreen 
              systemId={licenseStatus?.systemId || ''} 
              isExpired={licenseStatus?.isExpired || false} 
              daysRemaining={licenseStatus?.daysRemaining || 0}
              onActivationSuccess={() => window.location.reload()} 
              onBack={licenseStatus?.isExpired ? undefined : () => setShowManualActivation(false)}
          />
      );
  }

  const globalBackgroundStyle: React.CSSProperties = defaultValues.backgroundImage ? {
    backgroundImage: `url(${defaultValues.backgroundImage})`,
    backgroundSize: 'cover',
    backgroundPosition: 'center',
    backgroundAttachment: 'fixed',
  } : {};

  if (!isLoggedIn || !currentUser) {
    return (
        <div style={globalBackgroundStyle} className="min-h-screen relative">
            {defaultValues.backgroundImage && <div className="absolute inset-0 bg-white/40 dark:bg-gray-900/60 backdrop-blur-[2px]"></div>}
            <div className="relative z-10 h-full">
                <Login 
                    onLogin={handleLogin} 
                    users={users} 
                    setUsers={setUsers} 
                    activeDatabaseId={activeDatabaseId} 
                    licenseStatus={licenseStatus}
                    onActivateClick={() => setShowManualActivation(true)}
                />
            </div>
            <Chat currentUser={null} departments={departments} chatMessages={chatMessages} setChatMessages={setChatMessages} isLoginScreen={true} />
        </div>
    );
  }

  return (
    <div style={globalBackgroundStyle} className="h-screen flex flex-col bg-white dark:bg-gray-900 transition-colors duration-300 relative overflow-hidden">
      {defaultValues.backgroundImage && <div className="absolute inset-0 bg-white/60 dark:bg-gray-900/60 backdrop-blur-[2px] pointer-events-none z-0"></div>}
      
      <div className="relative z-10 flex flex-col h-full">
        {licenseStatus && !licenseStatus.isActivated && (
            <div className="fixed bottom-0 left-0 right-0 bg-yellow-500 text-black flex justify-between items-center px-4 py-1 z-50 text-sm font-bold print:hidden">
                <span>نسخة تجريبية - متبقي {licenseStatus.daysRemaining} يوم</span>
                <span>© {new Date().getFullYear()} جميع الحقوق محفوظة لـ ProDev Solutions</span>
            </div>
        )}
        <TopNav onNavigate={(view) => { if(view === 'settingsActivation') setShowManualActivation(true); else setCurrentView(view); }} currentUser={currentUser} licenseStatus={licenseStatus} user={currentUser.fullName} onLogout={handleLogout} theme={theme} onThemeChange={setTheme} currentViewLabel={currentViewLabel} isCloudConnected={isCloudConnected} updateAvailable={updateAvailable} firebaseConfig={firebaseConfig} isDBReady={isDBReady} />
        <main className="flex-1 p-6 overflow-y-auto">
            {notification && <ActionFeedback type={notification} />} 
            {renderCurrentView()}
        </main>
        <Chat currentUser={currentUser!} departments={departments} chatMessages={chatMessages} setChatMessages={setChatMessages} />
        {isLogoutModalOpen && (
            <Modal show={isLogoutModalOpen} onClose={() => setIsLogoutModalOpen(false)} title="تنبيه قبل الخروج">
                <div className="p-6 text-center">
                    <WarningIcon className="h-16 w-16 text-yellow-500 mx-auto mb-4" />
                    <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">هل قمت بعمل نسخة احتياطية؟</h3>
                    <p className="text-gray-600 dark:text-gray-400 mb-6">يرجى التأكد من أخذ نسخة احتياطية من بياناتك قبل الخروج للحفاظ عليها.</p>
                    <div className="flex justify-center space-x-4 space-x-reverse">
                        <button onClick={() => { setIsLogoutModalOpen(false); setCurrentView('backupSettings'); }} className="bg-blue-600 text-white px-6 py-2 rounded-lg font-bold hover:bg-blue-700 transition-colors">الذهاب للنسخ الاحتياطي</button>
                        <button onClick={performLogout} className="bg-red-600 text-white px-6 py-2 rounded-lg font-bold hover:bg-red-700 transition-colors">الخروج الآن</button>
                    </div>
                </div>
            </Modal>
        )}
      </div>
    </div>
  );
};
export default App;
